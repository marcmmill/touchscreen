package cobm;

import static org.junit.Assert.*;

import java.io.IOException;
import java.security.GeneralSecurityException;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.DateTime;
import com.google.api.services.calendar.model.Event;
import roomSchedule.GoogleCalendar;




public class GoogleCalendarTest {
  String tokensPath = "C:\\Users\\Cole\\Desktop\\app\\tokens";
  String calendarId = "iroih58nrhfu9bvivhpcttc22g@group.calendar.google.com";
  String client = "C:\\Users\\Cole\\Desktop\\app\\client_id.json";

  @Rule
  public ExpectedException thrown = ExpectedException.none();

  @Test
  public void TestGoogleCalendarAllNull() throws IOException {
    GoogleCalendar gc = new GoogleCalendar(null, null, null, null, null);
    List<Event> event = gc.getEvents();
    thrown.expect(NullPointerException.class);
    throw new NullPointerException();
  }

  @Test
  public void TestGoogleCalendarApplicationNameNotNull() throws IOException {
    GoogleCalendar gc = new GoogleCalendar("a", null, null, null, null);
    List<Event> event = gc.getEvents();
    thrown.expect(NullPointerException.class);
    throw new NullPointerException();
  }

  @Test
  public void TestGoogleCalendarJSONFactoryNotNull() throws IOException {
    GoogleCalendar gc = new GoogleCalendar(null,
        JacksonFactory.getDefaultInstance(), null, null, null);
    List<Event> event = gc.getEvents();
    thrown.expect(NullPointerException.class);
    throw new NullPointerException();
  }

  @Test
  public void TestGoogleCalendarTokensPathNotNull() throws IOException {
    String tokensPath = "StoredCredential";
    GoogleCalendar gc = new GoogleCalendar(null, null, tokensPath, null, null);
    List<Event> event = gc.getEvents();
    thrown.expect(NullPointerException.class);
    throw new NullPointerException();
  }

  @Test
  public void TestGoogleCalendarCalendarIDNotNull() throws IOException {
    GoogleCalendar gc = new GoogleCalendar(null, null, null,
        "qhvj3ef6lcm83mcebjfc531ihg@group.calendar.google.com", null);
    List<Event> event = gc.getEvents();
    thrown.expect(NullPointerException.class);
    throw new NullPointerException();
  }

  @Test
  public void TestGoogleCalendarClientIDNotNull() throws IOException {
    String clientID = "client_id.json";
    GoogleCalendar gc = new GoogleCalendar(null, null, null, null, clientID);
    List<Event> event = gc.getEvents();
    thrown.expect(NullPointerException.class);
    throw new NullPointerException();
  }

  @Test(expected = Test.None.class /* no exception expected */)
  public void TestGoogleCalendarCreateCalendar()
      throws IOException, GeneralSecurityException {
    GoogleCalendar gc = new GoogleCalendar("Application Name",
        JacksonFactory.getDefaultInstance(), tokensPath, calendarId, client);
    gc.buildAuthorizedClientService();
  }

  @Test
  public void TestGoogleCalendarGetEventsNotNull()
      throws IOException, GeneralSecurityException {

    GoogleCalendar gc = new GoogleCalendar("Application Name",
        JacksonFactory.getDefaultInstance(), tokensPath, calendarId, client);
    gc.buildAuthorizedClientService();
    assertNotNull(gc.getEvents());
  }
  

  @Test
  public void TestGoogleCalendarAddEventsFalse()
      throws IOException, GeneralSecurityException {
    GoogleCalendar gc = new GoogleCalendar("Application Name",
        JacksonFactory.getDefaultInstance(), tokensPath, calendarId, client);
    gc.buildAuthorizedClientService();
   // assertFalse(gc.addEvents(new ArrayList<roomSchedule.Data>()));
  }
  
  @Test
  public void TestGoogleCalendarSearchEventsNotNull()
      throws IOException, GeneralSecurityException {
    GoogleCalendar gc = new GoogleCalendar("Application Name",
        JacksonFactory.getDefaultInstance(), tokensPath, calendarId, client);
    gc.buildAuthorizedClientService();
    double oneAndHalfMonthsInMillis = 3944619000f;
    assertNotNull(gc.searchEvents("T114", new DateTime(new Date((long) (System.currentTimeMillis() - oneAndHalfMonthsInMillis))), new DateTime(new Date(System.currentTimeMillis()))));
  }
  @Test
  public void TestGoogleCalendarSearchEventsNull()
      throws IOException, GeneralSecurityException {
    GoogleCalendar gc = new GoogleCalendar("Application Name",
        JacksonFactory.getDefaultInstance(), tokensPath, calendarId, client);
    gc.buildAuthorizedClientService();
    assertNull(gc.searchEvents("T114", new DateTime(new Date((long) (System.currentTimeMillis()))), new DateTime(new Date(System.currentTimeMillis()))));
  }
  

}
