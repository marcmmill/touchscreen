package roomSchedule;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Read {

	public static void read(ArrayList<Data> data, String path) {
		String line = "";
		String cvsSplitBy = ",";
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		SimpleDateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date SD = null;
		Date ED = null;
		Date ST = null;
		Date ET = null;

	
		try (BufferedReader br = new BufferedReader(new FileReader(path))) {
			br.readLine();
			while ((line = br.readLine()) != null) {

				String[] temp = line.split(cvsSplitBy);

				try {

					Date StartDate = dateFormat.parse(temp[1]);
					Date EndDate = dateFormat.parse(temp[2]);
					Date StartTime = timeFormat.parse(temp[3]);
					Date EndTime = timeFormat.parse(temp[4]);

					SD = StartDate;
					ED = EndDate;
					ST = StartTime;
					ET = EndTime;

				} catch (ParseException e) {
					e.printStackTrace();
				}

				data.add(new Data(temp[0], SD, ED, ST, ET, temp[5], temp[6], temp[7], temp[8]));
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
