package roomSchedule;

import java.util.Date;

public class Data {

	private String Room;
	private String Hours;
	private String Activity;
	private String Section;
	private String DayofWeek;
	private Date StartDate;
	private Date EndDate;
	private Date StartTime;
	private Date EndTime;

	public Data(String Room, Date sD, Date eD, Date sT, Date eT, String Hours, String Activity, String Section,
			String DayofWeek) {
		// TODO Auto-generated constructor stub
		this.Room = Room;
		this.StartDate = sD;
		this.EndDate = eD;
		this.StartTime = sT;
		this.EndTime = eT;
		this.Hours = Hours;
		this.Activity = Activity;
		this.Section = Section;
		this.DayofWeek = DayofWeek;

	}

	public String getRoom() {
		return Room;
	}

	public void setRoom(String room) {
		this.Room = room;
	}

	public String getHours() {
		return Hours;
	}

	public void setHours(String hours) {
		this.Hours = hours;
	}

	public String getActivity() {
		return Activity;
	}

	public void setActivity(String activity) {
		this.Activity = activity;
	}

	public String getSection() {
		return Section;
	}

	public void setSection(String section) {
		this.Section = section;
	}

	public String getDayofWeek() {
		return DayofWeek;
	}

	public void setDayofWeek(String dayofWeek) {
		this.DayofWeek = dayofWeek;
	}

	public Date getStartDate() {
		return StartDate;
	}

	public void setStartDate(Date startDate) {
		this.StartDate = startDate;
	}

	public Date getEndDate() {
		return EndDate;
	}

	public void setEndDate(Date endDate) {
		this.EndDate = endDate;
	}

	public Date getEndTime() {
		return EndTime;
	}

	public void setEndTime(Date endTime) {
		this.EndTime = endTime;
	}

	public Date getStartTime() {
		return StartTime;
	}

	public void setStartTime(Date startTime) {
		this.StartTime = startTime;
	}

	public String toString() {
		return "Room : " + Room + " | Start Date: " + StartDate + " | End date: " + EndDate + " | Start time: "
				+ StartTime + " | End Time: " + EndTime + " | Hours: " + Hours + " | Activity: " + Activity
				+ " | Section: " + Section + " | Day of the week: " + DayofWeek;
	}

}
