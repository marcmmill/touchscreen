package roomSchedule;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Scanner;

import com.google.api.client.json.jackson2.JacksonFactory;

public class RunCalendar {

	private static ArrayList<Data> data = new ArrayList<Data>();
	private static String CSVpath = null;
	private static String tokensPath = "tokens";
//	private static String calendarID = null;
	private static String clientID = "client_id.json";
	private static String applicationName = "Google Calendar Room Data";
	   static Scanner sc = null;
	public static void main(String[] args) {
	
	//	ArrayList<Data> data = new ArrayList<Data>();
	
		
		
		
	       if(args == null || args.length == 0) {
             try {
                    for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                        if ("Nimbus".equals(info.getName())) {
                            javax.swing.UIManager.setLookAndFeel(info.getClassName());
                            break;
                        }
                    }
                } catch (ClassNotFoundException ex) {
                    java.util.logging.Logger.getLogger(DataConvertUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (InstantiationException ex) {
                    java.util.logging.Logger.getLogger(DataConvertUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (IllegalAccessException ex) {
                    java.util.logging.Logger.getLogger(DataConvertUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                } catch (javax.swing.UnsupportedLookAndFeelException ex) {
                    java.util.logging.Logger.getLogger(DataConvertUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
                }
                //</editor-fold>
                
              
                /* Create and display the form */
                java.awt.EventQueue.invokeLater(new Runnable() {
                    public void run() {
                    	DataConvertUI ui = new DataConvertUI();
                    	ui.requestFocusInWindow();
                    	ui.setVisible(true);
                        //new DataConvertUI().requestFocusInWindow().setVisible(true);
                    }
                });
               

              
               
	       }
		
		
	    else if (args[0] != null) {
			CSVpath = args[0];
			DataConvertUI.processCSVPath = false;
			 createCalendar(CSVpath);
	    }
			
	       
	}

	



	public static void createCalendar(String file) {
	  /* Error checking for the comma separated value file */
    
	   if(!DataConvertUI.processCSVPath) {
	  try {
          File cs = new File(CSVpath);
          if (!cs.getAbsolutePath().endsWith(".csv") || !cs.isFile()) {
              System.out.println("The filename is incorrect. "
                      + "Filename must include (excluding the single quotation marks) '.csv' - Example: 'roomdata.csv'");
              System.out.println("Reminder: The file must be in the same directory as the runnable JAR file.");
              return;
          }
          if (!cs.canRead()) {
              System.out.println("Do not have read permission for " + cs.getAbsolutePath());
              return;
          }
      } catch (NullPointerException e) {
          System.out.println("The pathname argument is null. The filename is incorrect. "
                  + "Filename must include (excluding the single quotation marks) '.csv' - Example: 'roomdata.csv'");
          System.out.println("Reminder: The file must be in the same directory as the runnable JAR file.");
          return;
      } // end of error checking CSV
	 }
      
      /* Error checking for client_id file */
      try {
          File cs = new File(clientID);
          if (!cs.getAbsolutePath().endsWith(".json") || !cs.isFile()) {
              System.out.println(
                      "The filename is incorrect. The file must be named (excluding the single quotation marks) "
                              + " 'client_id.json'");
              System.out.println("Reminder: The file must be in the same directory as the runnable JAR file.");
              return;
          }
          if (!cs.canRead()) {
              System.out.println("Do not have read permission for " + cs.getAbsolutePath());
              return;
          }
      } catch (NullPointerException e) {
          System.out.println("The pathname argument is null. The filename is incorrect. The file must be named "
                  + "(excluding the single quotation marks) " + " 'client_id.json'");
          System.out.println("Reminder: The file must be in the same directory as the runnable JAR file.");
          return;
      }// end of error checking client_id

      
      /* Error checking for tokens folder and credentials file */
      try {
          File cs = null;
          File tokensFolder = new File(tokensPath);
          if(tokensFolder.isDirectory() && tokensFolder.list().length > 0) {
              File [] credentials =  tokensFolder.listFiles();
               cs = credentials[0]; 
          }
          if(cs != null) {
          if (!cs.getAbsolutePath().endsWith("StoredCredential") || !cs.isFile()) {
              System.out.println(
                      "The filename is incorrect. The file must be named (excluding the single quotation marks) "
                              + " 'StoredCredential'");
              System.out.println("Reminder: The file must be in the same directory as the runnable JAR file.");
              return;
          } 

          if (!cs.canRead()) {
              System.out.println("Do not have read permission for " + cs.getAbsolutePath());
              return;
          }
          }
      } catch (NullPointerException e) {
          System.out.println("The pathname argument is null. The filename is incorrect. The file must be named "
                  + "(excluding the single quotation marks) " + " 'StoredCredential'");
          System.out.println("Reminder: The file must be in the same directory as the runnable JAR file.");
          return;
      }// end of error checking for credentials

      
//      /* Error checking for calendar id */
//      try {
//
//          File cs = new File("calendarid.txt");
//          if (!cs.getAbsolutePath().endsWith(".txt") || !cs.isFile()) {
//              System.out.println(
//                      "The filename is incorrect. The file must be named (excluding the single quotation marks) "
//                              + " 'calendarid.txt'");
//              System.out.println("Reminder: The file must be in the same directory as the runnable JAR file.");
//              return;
//          }
//
//          if (!cs.canRead()) {
//              System.out.println("Do not have read permission for " + cs.getAbsolutePath());
//              return;
//          }
//
//          sc = new Scanner(cs);
//          if (sc.hasNextLine()) {
//              calendarID = sc.nextLine();
//              sc.close();
//          } else {
//              sc.close();
//              System.out.println("The file is empty. Please copy the calendar id into the FIRST LINE of the file."
//                      + "Example of calendar id (excluding the single quotation marks): "
//                      + "'qhva3ef6lcn83mcedjfc931ihg@group.calendar.google.com' ");
//          }
//
//      } catch (NullPointerException | FileNotFoundException e) {
//          sc.close();
//          System.out.println("The pathname argument is null. The filename is incorrect. The file must be named "
//                  + "(excluding the single quotation marks) " + " 'calendarid.txt''");
//          System.out.println("Reminder: The file must be in the same directory as the runnable JAR file.");
//          return;
//      } // end of error checking calendar id
		// TODO Auto-generated method stub
		
      Read.read(data, file);
		GoogleCalendar cDemo = new GoogleCalendar(applicationName, JacksonFactory.getDefaultInstance(), tokensPath,
				"primary", clientID);

		try {
			try {
				cDemo.buildAuthorizedClientService();
			} catch (GeneralSecurityException e) {
				e.printStackTrace();
			}
			
			if (data != null && data.size() > 0) {
				System.out.println("\nPlease wait while your data is uploading to Google Calendar. "
						+ "This could take a few minutes (depending on the size of the roomdata.csv file).");
			}
			
			cDemo.createMap();
			int i = 1;
			for(Data entry : data) {
				String room = entry.getRoom();
			if(cDemo.calendarExists(room)) {
				String calendarID = cDemo.getCalendarID(room);
				cDemo.addEvents(entry, calendarID);
			}else {
				com.google.api.services.calendar.model.Calendar cal = cDemo.createCalendar(room);
				cDemo.addEvents(entry, cal.getId());
			}
			i++;
			}
			System.out.println("Number of items processed:" + i);

			// TODO REMOVE THIS cDemo.addEvents(data);
			//cDemo.getEvents();
	
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
	}//end ert
}
