package roomSchedule;

import java.io.FileInputStream;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.GeneralSecurityException;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.util.DateTime;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.Calendar.CalendarList;
import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.calendar.model.CalendarListEntry;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.EventDateTime;
import com.google.api.services.calendar.model.Events;

public class GoogleCalendar {

	private final String APPLICATION_NAME;
	private final JsonFactory JSON_FACTORY;
	private final String TOKENS_DIRECTORY_PATH;
	private final String calendarID;
	private Calendar service;
	private Map<String,String> map = new HashMap<String, String>();
	
	
	/**
	 * Global instance of the scopes required by this application. If modifying
	 * these scopes, delete your previously saved tokens/ folder.
	 */
	private static final List<String> SCOPES = Collections.singletonList(CalendarScopes.CALENDAR);
	private final String CREDENTIALS_FILE_PATH;

	/**
	 * 
	 * @param applicationName     The application name to be used in the UserAgent
	 *                            header of each request or null for none.
	 * 
	 * @param jsonFactory         A JSON factory
	 * @param tokensDirectoryPath The path where the tokens will be stored
	 * @param calendarID          The ID of the calendar to connect to Googles API
	 */
	public GoogleCalendar(String applicationName, JsonFactory jsonFactory, String tokensDirectoryPath,
			String calendarID, String clientID) {
		this.APPLICATION_NAME = applicationName;
		this.JSON_FACTORY = jsonFactory;
		this.TOKENS_DIRECTORY_PATH = tokensDirectoryPath;
		this.calendarID = calendarID;
		this.CREDENTIALS_FILE_PATH = clientID;

	}

	/**
	 * Creates an authorized Credential object.
	 * 
	 * @param HTTP_TRANSPORT The network HTTP Transport.
	 * @return An authorized Credential object.
	 * @throws IOException If the credentials.json file cannot be found.
	 */
	private Credential getCredentials(final NetHttpTransport HTTP_TRANSPORT) throws IOException {
		// Load client secrets.
		java.io.File credentials = new java.io.File(CREDENTIALS_FILE_PATH);
		InputStream in = new FileInputStream(credentials.getAbsolutePath());

		GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

		// Build flow and trigger user authorization request.
		GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY,
				clientSecrets, SCOPES)
						.setDataStoreFactory(new FileDataStoreFactory(new java.io.File(TOKENS_DIRECTORY_PATH)))
						.setAccessType("offline").build();
		LocalServerReceiver receiver = new LocalServerReceiver.Builder().setPort(8888).build();

		return new AuthorizationCodeInstalledApp(flow, receiver).authorize("user");
	}

	public void buildAuthorizedClientService() throws GeneralSecurityException, IOException {
		// Build a new authorized API client service.
		final NetHttpTransport HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
		this.service = new Calendar.Builder(HTTP_TRANSPORT, JSON_FACTORY, getCredentials(HTTP_TRANSPORT))
				.setApplicationName(APPLICATION_NAME).build();
	}

	/**
	 * Gets all the upcoming events in the Google Calendar
	 * 
	 * @return List of upcoming events
	 * @throws IOException
	 */
	public List<Event> getEvents() throws IOException {
		if (service != null) {
			Events events = service.events().list(calendarID).execute();
			List<Event> items = events.getItems();
			if (items.isEmpty()) {
				System.out.println(events.getSummary());
				System.out.println("No upcoming events found.");
			} else {
				System.out.println("Upcoming events");
				for (Event event : items) {
					DateTime start = event.getStart().getDateTime();
					if (start == null) {
						start = event.getStart().getDate();
					}
					System.out.printf("%s (%s)\n", event.getSummary(), start);
				}
			}
			return items;
		}
		return null;
	}

	/**
	 * Adds events to the Google Calendar via an ArrayList
	 * 
	 * 
	 * @param data an ArrayList containing the room data
	 * @return boolean, true if the room data has been added to Google Calendar,
	 *         else false
	 * @throws IOException
	 */
	public boolean addEvents(Data entry, String calendarID) throws IOException {

		Event recurringEvent = new Event().setSummary(entry.getActivity()).setLocation(entry.getRoom())
				.setDescription(entry.getSection());

		LocalDateTime time = LocalDateTime.ofInstant(entry.getStartTime().toInstant(), ZoneId.systemDefault());
		LocalDateTime dateTime = LocalDateTime.ofInstant(entry.getStartDate().toInstant(), ZoneId.systemDefault())
				.withHour(time.getHour()).withMinute(time.getMinute()).withSecond(time.getSecond());

		Date startDateTime = Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant());

		time = LocalDateTime.ofInstant(entry.getEndTime().toInstant(), ZoneId.systemDefault());
		dateTime = LocalDateTime.ofInstant(entry.getStartDate().toInstant(), ZoneId.systemDefault())
				.withHour(time.getHour()).withMinute(time.getMinute()).withSecond(time.getSecond());

		Date endDateTime = Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant());

		DateTime finalStartDateTime = new DateTime(startDateTime);
		DateTime finalEndDateTime = new DateTime(endDateTime);

		EventDateTime start = new EventDateTime().setDateTime(finalStartDateTime).setTimeZone("Canada/Eastern");
		EventDateTime end = new EventDateTime().setDateTime(finalEndDateTime).setTimeZone("Canada/Eastern");

		recurringEvent.setStart(start);
		recurringEvent.setEnd(end);

		LocalDateTime ruleEndDateTime = LocalDateTime.ofInstant(entry.getEndDate().toInstant(), ZoneId.systemDefault());
		ruleEndDateTime = ruleEndDateTime.plusDays(7);
		Date ruleEndDate = Date.from(ruleEndDateTime.atZone(ZoneId.systemDefault()).toInstant());

		String rule = ruleEndDate.toInstant().toString();
		rule = rule.replace(":", "");
		rule = rule.replace("-", "");
		rule = "RRULE:FREQ=WEEKLY;UNTIL=" + rule + ";BYDAY=" + entry.getDayofWeek().substring(0, 2).toUpperCase();

		recurringEvent.setRecurrence(Arrays.asList(rule));

		recurringEvent = service.events().insert(calendarID, recurringEvent).execute();

		return false;
	}

	/**
	 * Returns a List of events given the search parameters.
	 * 
	 * @param roomNumber the string of the room you would like to search for ex.
	 *                   T135
	 * @param startTime  the start time to filter the results Must be an RFC3339
	 *                   time stamp with mandatory time zone offset, for example,
	 *                   2011-06-03T10:00:00-07:00, 2011-06-03T10:00:00Z
	 * @param endTime    the end time used to filter the results Must be an RFC3339
	 *                   time stamp with mandatory time zone offset, for example,
	 *                   2011-06-03T10:00:00-07:00, 2011-06-03T10:00:00Z
	 * @return null if the list size is 0 or the parameters are null else it returns
	 *         a List of upcoming events
	 * @throws IOException
	 */
	public List<Event> searchEvents(String roomNumber, DateTime startTime, DateTime endTime) throws IOException {
		if (roomNumber != null || startTime != null || endTime != null) {
			Events events = service.events().list(calendarID).setTimeZone("Canada/Eastern").setTimeMin(startTime)
					.setTimeMax(endTime).execute();
			List<Event> items = events.getItems();
			if (items != null && items.size() > 0) {
				List<Event> filteredItems = new ArrayList<Event>();
				for (Event event : items) {
					if (roomNumber.equals(event.getLocation())) {
						filteredItems.add(event);
					}
				}
				return filteredItems;
			}
		}
		return null;
	}
	
	
	public String getCalendarID(String roomNumber) {
		return map.get(roomNumber);
	}
	
	
	public void createMap() {
		String pageToken = null;
		do {
		  com.google.api.services.calendar.model.CalendarList calendarList = null;
		try {
			calendarList = service.calendarList().list().setPageToken(pageToken).execute();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  List<CalendarListEntry> items = calendarList.getItems();

		  for (CalendarListEntry calendarListEntry : items) {
		   // System.out.println(calendarListEntry.getSummary());
		  //  System.out.println(calendarListEntry.getId());
		    map.put(calendarListEntry.getSummary(),calendarListEntry.getId()); 
		  //map.get(key);
		  }
		  pageToken = calendarList.getNextPageToken();
		} while (pageToken != null);
	}
	
	public com.google.api.services.calendar.model.Calendar createCalendar(String roomNumber) throws IOException {
		com.google.api.services.calendar.model.Calendar calendar = new com.google.api.services.calendar.model.Calendar();
		calendar.setSummary(roomNumber);
		calendar.setTimeZone("Canada/Eastern");
		com.google.api.services.calendar.model.Calendar createdCalendar = service.calendars().insert(calendar).execute();	
		map.put(createdCalendar.getSummary(), createdCalendar.getId());
		return createdCalendar;
	}
	
	public boolean calendarExists(String roomNumber) {
		if(map.get(roomNumber) != null) {
			return true;
		}
		return false;
	}
	
	


}
